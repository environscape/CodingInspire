# xLoader — Coding Inspire Modular 模块固件升级工具



---

## 第一步：解压缩

将整个 `xLoader` 文件夹 **解压到电脑上的任意位置**（比如桌面或 D 盘），确保里面包含 `XLoader.exe` 程序即可。

---

## 第二步：认识固件文件

你下载好的 Coding Inspire Modular 模块固件是一个 `.hex` 文件。(UF2 格式固件有另外的升级方法，请前往特定模块的说明书进行查看)

**判断方法：**
看升级文件名中写的是 **`328`** 还是 **`168`**，然后选择对应的设置方式。

---

## 第三步：打开 xLoader 并配置

双击运行 `XLoader.exe`，你会看到这样一个界面：

![xLoader 主界面](atmega328.png)

### 配置选项说明

xLoader 中需要设置以下 4 项：

| 选项 | 说明 |
|------|------|
| **HEX File** | 选择你要刷写的固件 `.hex` 文件 |
| **Device** | 选择单片机型号 |
| **COM Port** | 选择模块连接的串口 |
| **Baud Rate** | 选择通讯速率 |

---

### 情况一：ATmega328P 芯片（文件名含 `328`）

参考下图进行设置：

![ATmega328P 设置](atmega328.png)

| 设置项 | 选择值 |
|--------|--------|
| Device | `Uno(ATmega328)` 或 `Duemilanove/Nano(ATmega328)` |
| Baud Rate | `115200` 或 `57600`（以实际截图标注为准） |

---

### 情况二：ATmega168P 芯片（文件名含 `168`）

参考下图进行设置：

![ATmega168P 设置](atmega168.png)

| 设置项 | 选择值 |
|--------|--------|
| Device | `Duemilanove/Nano(ATmega168)` |
| Baud Rate | `19200` |

---

## 第四步：开始升级

1. 将 Eurorack 模块通过 **USB 线** 连接到电脑
2. 在电脑的 **设备管理器**（右键"此电脑" → 管理 → 设备管理器）中，找到 **端口（COM 和 LPT）**，查看模块占用的是哪个 COM 口（例如 `COM3`）
3. 在 xLoader 的 **COM Port** 下拉菜单中选中这个端口
4. 点击 **Upload**（上传）按钮
5. 等待进度条走完，显示 **"Done!"** 即表示升级完成 ✅

---

## 常见问题

**Q: 点 Upload 后没反应或报错？**
A: 请检查：① COM 口是否选对 ② 模块是否正确连接 ③ 是否安装了 USB 驱动

**Q: 模块有多个固件版本，该刷哪个？**
A: 根据你的模块型号选择对应的 `.hex` 文件，文件名中的 `328` 或 `168` 决定了你需要参考哪张截图来设置。

**Q: 这个工具支持其他芯片吗？**
A: 本工具（xLoader）仅支持 **ATmega328P** 和 **ATmega168P** 两种芯片。如果你的 Eurorack 模块使用了其他型号的单片机，请使用其他的升级工具或升级方法。

---

> 💡 **小提示：** 升级固件前建议先记下模块当前的固件版本，方便升级后对比验证。



---

## 附录：官方英文说明（xLoader Original README）

# xLoader
xLoader is an utility to program or flash HEX file onto ATmega328 and other AVR Microcontrollers. We simply need to download and extract files in the folder. Then click on XLoader.exe <b>Note:</b> Create desktop shortcut for quick access

# How to Use
<p>The following steps will help us use XLoader to upload HEX file on ATmega328 (Arduino Uno).</p>

1. Open xLoader
2. Browse the HEX File from AVR Project/Atmeal Studio Project
3. Select the device E.g. In case of Arduino Uno, it's ATmega328
4. Select COM Port
5. Select right baud rate in case of Arduino Uno it's 115200
6. Finally hit Upload Button

<img src="https://github.com/binaryupdates/xLoader/blob/master/xloader_atmega328.jpg" alt="Girl in a jacket" align="center" width="400" height="300">
